package com.lemony.upgatesapi.repository.entity;

import javax.persistence.Entity;
import java.io.Serializable;

public class UpgatesEntity{

}
